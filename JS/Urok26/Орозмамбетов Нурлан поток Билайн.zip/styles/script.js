let age = 35;

let  year = 1986;

let name_ = "Nurlan";

console.log(age);
console.log(year);
console.log(name_);