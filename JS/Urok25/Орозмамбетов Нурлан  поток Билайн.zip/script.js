function getFullName () {
    let name_ = prompt('Введите ваше Имя');
    let surname = prompt('Введите Фамилию');
    console.log(surname, name_);
}
getFullName ();

function sum() {
    let fistNumber = prompt('Введите первое число');
    let secondNumber = prompt('Введите второе число');
    console.log(Number(fistNumber) + Number(secondNumber));
}
sum();

function multiplication() {
    let fistNumber = prompt('Введите первое число');
    let secondNumber = prompt('Введите второе число');
    console.log(Number(fistNumber) * Number(secondNumber));
}
multiplication();