let person = {
    name_: "Many",
    surname: "Men",
    age: 32,
    birth: 1993,
    place: "Chuy"
}

var sports = [
    "Футбол", "Баскетбол", "Теннис", "Волейбол"
]

console.log(person.name_);
console.log(person.surname);
console.log(person.age);
console.log(person.birth);
console.log(person.place);

console.log(sports[0]);
console.log(sports[1]);
console.log(sports[2]);
console.log(sports[3]);